# Города+ — Telegram-бот «Города» + GeoGuessr

Игровой Telegram-бот на aiogram 3: классическая цепочка городов и режим угадывания
города по панораме/фото. Базовый режим работает на **бесплатных API без ключей**
(Nominatim, Photon, Open-Meteo, Wikipedia/Wikidata/Wikivoyage, Wikimedia Commons,
REST Countries, KartaView, Panoramax, OSM Static Map, MyMemory, Nager.Date,
Overpass и другие), поэтому запускается сразу после заполнения `BOT_TOKEN`.
Всего в реестре **77 провайдеров** и **16 каскадов**; провайдеры с ключами
подключаются опционально и без токена просто пропускаются.

## Возможности

| Блок | Что умеет |
|------|-----------|
| 🏙 Города | цепочка городов, бот-соперник, очки за население/сложность, подсказки, сдача партии, таймер хода |
| 🌍 GeoGuessr | панорама/фото локации, ответ по координатам, расстояние по haversine, очки и XP |
| 🌐 Города мира | справочник из 112 городов 70 стран в русской транслитерации (Париж, Токио, Йоханнесбург…) |
| 👤 Профиль | уровень, XP, статистика, достижения с пагинацией, история партий, рейтинг |
| ⚙️ Настройки | сложность, язык интерфейса, уведомления |
| 🛡 Устойчивость | каскад провайдеров, квоты, circuit breaker, кэш Redis, retry с jitter |

## Требования

- Python 3.12+ (код совместим с 3.13)
- SQLite для локального запуска (PostgreSQL/Redis — для Docker-профиля)
- Токен бота от [@BotFather](https://t.me/BotFather)

## Быстрый старт (локально, SQLite)

```bash
# 1. зависимости (в свежем venv, чтобы не ловить чужие версии)
python -m venv .venv && . venv\Scripts\activate      # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt         # рантайм
python -m pip install -r requirements-dev.txt     # тесты, линтеры

# 2. окружение
cp .env.example .env      # Windows: copy .env.example .env
#   вписать BOT_TOKEN=... и ADMIN_IDS=...

# 3. запуск
python -m app.main        # или: python run.py (только polling)
# ВАЖНО: именно `python -m app.main` — точка, не двоеточие.
# `python app.main` ищет файл «app.main» и падает с [Errno 2].
```

Если `api.telegram.org` недоступен напрямую (запуск падает с
`TelegramNetworkError: Request timeout error`), задайте в `.env`
`BOT_PROXY=http://127.0.0.1:3128` или `BOT_PROXY=socks5://127.0.0.1:1080`
(для socks нужен `pip install aiohttp_socks`). Проверить всё, кроме Telegram,
можно офлайн: `python -m scripts.healthcheck` и `python check.py`.

При первом старте создаются каталоги `data/` и `logs/`, схема БД накатывается
через `init_models()` (dev-режим), кэш и FSM работают в памяти процесса
(`InMemoryRedis` + `MemoryStorage`), внешние ключи API не нужны.

## Проверки

```bash
python scripts/healthcheck.py   # офлайн-самопроверка: 11 шагов, отчёт в logs/healthcheck.json
python check.py                 # быстрый смоук: импорты, роутеры, диспетчер
python -m pytest                # юнит/интеграционные тесты
```

`healthcheck.py` не требует Telegram, Redis и сети: проверяет конфиг, импорты,
схему БД (12 таблиц), кэш, скоринг, сервисы, движок городов, GeoGuessr,
каскад провайдеров и сборку роутеров.

> ⚠️ Статус проверки: код и документация подготовлены, но в среде разработки
> запуск `python.exe` блокируется политикой хоста (`Access is denied`), поэтому
> команды выше в этой среде не прогонялись — прогоните их локально.

## Конфигурация

Все настройки — через переменные окружения (`.env`), см. [.env.example](.env.example).
Ключевое:

- `BOT_TOKEN` — токен бота (единственный обязательный параметр в production);
- `DATABASE_URL` — по умолчанию `sqlite+aiosqlite:///./data/cities_bot.db`;
- `REDIS_URL` / `FSM_REDIS_URL` — пусто = in-memory;
- `PROVIDER_ORDER_*` — переопределение порядка каскада провайдеров;
- ключи платных API (`GEONAMES_USERNAME`, `OPENCAGE_API_KEY`, …) необязательны:
  без них провайдер помечается `is_configured=False` и пропускается.

## Структура

```
app/
  handlers/      # роутеры aiogram (тонкие, логика — в сервисах)
  services/      # бизнес-логика + services/external/ (провайдеры и каскад)
  repositories/  # доступ к данным поверх SQLAlchemy 2 async
  models/        # ORM-модели
  schemas/       # pydantic-схемы
  keyboards/     # inline/reply-клавиатуры и фабрики callback-данных
  middlewares/   # сессия БД, конфиг, троттлинг, логирование
  utils/         # валидаторы, кэш, ретраи, квоты, circuit breaker
migrations/      # Alembic (0001 baseline + ревизии)
scripts/         # healthcheck, подготовка данных
tests/           # unit / integration / external с моками провайдеров
docs/            # архитектура, ER, деплой, тестирование, решения
```

## Документация

- [docs/architecture.md](docs/architecture.md) — слои и потоки данных
- [docs/gameplay.md](docs/gameplay.md) — правила режимов и скоринг
- [docs/api_integrations.md](docs/api_integrations.md) — провайдеры, каскад, квоты
- [docs/deployment.md](docs/deployment.md) — Docker Compose, PostgreSQL, Redis, webhook
- [docs/testing.md](docs/testing.md) — как гонять тесты и моки
- [docs/security.md](docs/security.md) — секреты, валидация, ограничения
- [docs/decisions.md](docs/decisions.md) — журнал архитектурных решений

## Docker

```bash
docker compose up --build                  # бот + PostgreSQL + Redis (миграции до старта)
docker compose --profile translate up -d  # дополнительно локальный LibreTranslate
```

По умолчанию поднимаются бот, PostgreSQL и Redis; миграции применяются до старта
приложения. LibreTranslate вынесен в отдельный профиль `translate` и запускается
только по явному флагу. Подробности — в [docs/deployment.md](docs/deployment.md).

## Лицензия

См. [LICENSE](LICENSE).
